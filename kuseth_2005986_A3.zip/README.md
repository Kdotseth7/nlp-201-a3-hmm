# Instructions to run code on local
Run kuseth_2005986.ipynb file
